# LL.B. Indian Law Case Catalogue publisher

This package adds a separate, mobile-first case-law layer to `Legedith/llb` while preserving the existing curriculum DAG and study pages.

## What it builds

- `/cases/` — searchable catalogue.
- `/cases/<case-id>/` — one full case guide per decision.
- `/cases/trails/` — doctrine-development trails.
- `/cases/compare/` — side-by-side comparison of two to four cases.
- `/cases/review/` — visible verification and metadata gaps.
- `/cases/method/` — editorial and source methodology.
- `/subjects/<subject-id>/cases/` — a digital casebook for each of the 45 papers.
- `#cases` on every one of the 4,337 curriculum-node pages.

The editable source lives in `casebook/`; generated HTML and indexes are rebuilt by GitHub Actions.

## Current seed

- 254 decisions.
- 665 holding-to-node links.
- 548 distinct curriculum nodes with mapped cases.
- 27 doctrine trails.
- 119 explicitly labelled editorial doctrine-development links.
- 0 paragraph-pinned direct judicial-treatment edges.
- Coverage across all 45 papers.

The zero is deliberate. The catalogue does not convert an educational sequence into a claim that one judgment followed, distinguished, limited, or overruled another. Direct treatment is published only after the later judgment and relevant paragraphs are checked.

## Files to publish

Copy the package contents into the root of the repository, preserving paths. The important additions are:

```text
.github/workflows/build-site.yml
tools/enrich_nodes.py
tools/build_cases.py
casebook/
```

The workflow regenerates the existing graph and study pages, builds the case catalogue, validates all routes and links, commits generated output to `main`, and lets the existing root-based GitHub Pages configuration deploy it.

Read `INSTALL.md` before publishing and `casebook/README.md` before editing case records.
