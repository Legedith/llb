# Installation and publication

## Target

Repository: `Legedith/llb`  
Branch: `main`  
GitHub Pages source: repository root

The package was prepared against main commit `32e1942600b2133647139a940010594f4caf1423`.

## Install

Copy every file and directory in this package into the repository root, preserving paths. Existing files with the same path should be replaced.

Expected source layout:

```text
.github/workflows/build-site.yml
casebook/
tools/build_site.py          # already in the repository
tools/enrich_nodes.py        # replace with package version
tools/build_cases.py         # new
```

Commit and push these source files to `main`. The `Build LL.B. study library and case catalogue` workflow starts automatically.

## What the workflow does

1. Compiles and checksum-verifies the study and case generators.
2. Rebuilds the canonical curriculum DAG.
3. Rebuilds all 4,337 dedicated study pages.
4. Generates the 254-case catalogue, 27 trails, 45 paper casebooks, review queue, method page, comparison route, and machine-readable indexes.
5. Injects a case-law section into all curriculum node pages.
6. Validates graph acyclicity, study coverage, case-page sections, internal links, route coverage, source-state files, and the absence of unverified direct treatment edges.
7. Replaces generated root output while preserving `.github/`, `tools/`, and `casebook/` source.
8. Commits generated output back to `main` using `github-actions[bot]`.
9. Allows the existing Pages workflow to deploy the root.

## Expected validated counts

```text
Subjects                         45
Modules                          384
Topics                         3,882
All curriculum nodes           4,337
Strict prerequisite edges      4,043
Dedicated study pages          4,337
Cases                             254
Holding-to-node links             665
Mapped curriculum nodes           548
Doctrine trails                    27
Editorial development links       119
Direct treatment edges               0
Paper casebooks                     45
Node pages patched              4,337
Node pages with mapped cases      819
```

## Failure interpretation

A build failure is intended to stop publication when an ID, holding link, node link, case route, trail stage, or required section is missing. A failure because expected counts changed is not necessarily a content error; update the workflow’s expected counts only after reviewing the intended source changes.

## Post-deployment checks

Open:

```text
/cases/
/cases/review/
/cases/method/
/cases/trails/
/cases/compare/
/subjects/lb-401/cases/
/cases/sc-1978-maneka-gandhi-v-union-of-india/
/nodes/lb-401.m03.s13/#cases
```

Confirm mobile navigation, filtering, bookmarks, comparison, official-source links, and node-to-case navigation.
